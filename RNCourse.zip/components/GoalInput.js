import { useState } from "react";
import { Button, Image, Modal, Pressable, StyleSheet, TextInput, View } from "react-native";

function GoalInput(props) {
    const [enteredGoalText, setEnteredGoalText] = useState('');

    const goalInputHandler = (enteredText) => {
        setEnteredGoalText(enteredText)
    }

    const onAdd = () => {
        props.addGoalHundler(enteredGoalText);
        setEnteredGoalText('');
    }

    // console.log(ddd)

    return (
        <Modal visible={props.visible} animationType="slide">
            <View style={styles.inputContainer}>
                <Image style={styles.img} source={require('../assets/images/goal.png')} />
                <TextInput style={styles.inputText} placeholderTextColor='#fff' placeholder='Your app goals' onChangeText={goalInputHandler} value={enteredGoalText} />
                <View style={styles.buttonContainer}>
                    <View style={styles.button}>
                        <Button title='Add goal' onPress={onAdd} />
                    </View>
                    <View style={styles.button}>
                        <Button title='Cancel' onPress={props.onCancel} />
                    </View>
                </View>
            </View>
           
        </Modal>
    )
}

export default GoalInput;

const styles = StyleSheet.create({
    inputContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        // marginBottom: 24,
        padding: 16,
        backgroundColor: '#1e085a',
    },
    img: {
        width: 100,
        height: 100,
        margin: 20,
    },
    inputText: {
        borderWidth: 1,
        borderColor: '#ccc',
        width: '100%',
        padding: 16,
        color: '#fff',
        borderRadius: 4,
    },
    buttonContainer: {
        marginTop: 16,
        flexDirection: 'row',
        justifyContent: 'center'
    },
    button: {
        width: 100,
        marginHorizontal: 8,
    }
})